/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package top.january;

/**
 *
 * @author janua
 */
class MainCallback {
    public void onDownloadStart(FileRecord record, String localPath, String remotePath){
        
    }
    
    public void onDownload(int addSize){
        
    }
    
    public void onDownloadFailed(){
        
    }
    
    public void onDownloadEnd(){
        
    }
    
    public void onUploadStart(FileRecord record, String localPath, String remotePath){
        
    }
    
    public void onUpload(int addSize){
        
    }
    
    public void onUploadFailed(){
        
    }
    
    public void onUploadEnd(){
        
    }
    
}
