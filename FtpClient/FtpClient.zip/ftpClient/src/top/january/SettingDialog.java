/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package top.january;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.security.auth.callback.ConfirmationCallback;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/**
 *
 * @author janua
 */
public class SettingDialog extends JDialog{
    private JPanel mainPanel;
    JButton confirm, quit;
    JLabel host, username, password;
    JTextField hostTextField, usernameTextField;
    JPasswordField passwordField;
    Ftp ftp;
    public SettingDialog(Ftp _ftp) {
        super(FtpUI.mainWindow, "设置");
        ftp = _ftp;
        setSize(300, 180);
        setResizable(false);
        setLocationRelativeTo(FtpUI.mainWindow);
        mainPanel = new JPanel();
        setContentPane(mainPanel);
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        initUI();
        initEvent();

    }
    
    private void initUI(){
        
        
        
        Box box1 = Box.createHorizontalBox();
        host = new JLabel("服务器地址");
        hostTextField = new JTextField("127.0.0.1");
        host.setMaximumSize(new Dimension(80, 25));
        hostTextField.setMaximumSize(new Dimension(160, 25));
        
        Box box2 = Box.createHorizontalBox();
        username = new JLabel("用户名");
        usernameTextField = new JTextField("january");
        username.setMaximumSize(new Dimension(80, 25));
        usernameTextField.setMaximumSize(new Dimension(160, 25));
        
        Box box3 = Box.createHorizontalBox();
        password = new JLabel("密码");
        passwordField = new JPasswordField("120120");
        password.setMaximumSize(new Dimension(80, 25));
        passwordField.setMaximumSize(new Dimension(160, 25));
        
        Box box4 = Box.createHorizontalBox();
        confirm = new JButton("保存");
        quit = new JButton("取消");
        box4.add(confirm);
        box4.add(Box.createHorizontalStrut(20));
        box4.add(quit);
        
        
      
        box1.add(host);
        box1.add(hostTextField);
        box2.add(username);
        box2.add(usernameTextField);
        box3.add(password);
        box3.add(passwordField);
        
        mainPanel.add(Box.createVerticalGlue());
        mainPanel.add(box1);
        mainPanel.add(box2);
        mainPanel.add(box3);
        mainPanel.add(Box.createVerticalStrut(20));
        mainPanel.add(box4);
        mainPanel.add(Box.createVerticalGlue());
    
    }
    
    private void initEvent(){
        confirm.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ftp.SetHost(hostTextField.getText());
                ftp.setUser(usernameTextField.getText());
                ftp.setPass(String.valueOf(passwordField.getPassword()));
                dispose();
            }
        });
        
        quit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                System.out.println(".actionPerformed()");
            }
        });
    }

    
    
    @Override
    public void setVisible(boolean visible){
        super.setVisible(visible);
        if(visible){
            hostTextField.setText(ftp.getHost());
            usernameTextField.setText(ftp.getUser());
            passwordField.setText(ftp.getPass());
        }
    }
    
    
    
}
