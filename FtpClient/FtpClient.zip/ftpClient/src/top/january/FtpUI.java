package top.january;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
        
public class FtpUI extends JFrame{
    static FtpUI mainWindow = null;
    final String appName = "FTP client";
    Ftp ftp;
    private Container mainPanel;
    private GridBagLayout mainLayout;
    
    //菜单栏
    private JMenuBar menuBar;
    private JMenu optionMenu;
    private JMenuItem menuSetting;
    private JMenuItem menuConnect;
    private JMenuItem menuDisconnect;
    private JMenu aboutMenu;
    private JMenuItem menuAbout;
    
    //本地文件显示区域
    FileViewer localFileViewer;
    
    //远程文件显示区域
    FileViewer remoteFileViewer;
    
    //任务区域
    TaskViewer taskViewer;
    
    //状态栏
    private StateBar stateBar;
    
    
    public static void main(String[] args){
        FtpUI mainFrame = new FtpUI();
        mainFrame.setVisible(true);
    }
    
    public FtpUI(){
        ftp = new Ftp();
        mainPanel = getContentPane();
        mainLayout = new GridBagLayout();
        mainPanel.setLayout(mainLayout);
        initComponent();
        initEventListener();
        FtpUI.mainWindow = this;
        
    }

    private void initComponent() {
        setTitle(appName);
        setSize(800, 600);
        initMenuBar();
        initLocalPanel();
    }
    private void initMenuBar(){
        menuBar = new JMenuBar();
        initOptionMenu();
        initAboutMenu();
        menuBar.add(optionMenu);
        menuBar.add(aboutMenu);
        setJMenuBar(menuBar);
    }
    private void initOptionMenu(){
        optionMenu = new JMenu("选项");
        menuSetting = new JMenuItem("设置");
        menuConnect = new JMenuItem("登录");
        menuDisconnect = new JMenuItem("断开");
        optionMenu.add(menuSetting);
        optionMenu.add(menuConnect);
        optionMenu.add(menuDisconnect);
    }
    private void initAboutMenu(){
        aboutMenu = new JMenu("关于");
        menuAbout = new JMenuItem("关于sftp");
        aboutMenu.add(menuAbout);
    }
    
    private void initLocalPanel(){
        localFileViewer = new FileViewer(ftp);
        remoteFileViewer = new RemoteFileViewer(ftp);
        taskViewer = new TaskViewer(ftp);
        stateBar = new StateBar();
        
        //设置布局
        GbcH posArg = new GbcH();
        mainLayout.setConstraints(localFileViewer, posArg.next());
        mainLayout.setConstraints(remoteFileViewer, posArg.next());
        posArg.nextLine(1, 0.5);
        mainLayout.setConstraints(taskViewer, posArg.next(2));
        posArg.nextLine(1, 0);
        mainLayout.setConstraints(stateBar, posArg.next());
        
       
        //添加组件
        mainPanel.add(localFileViewer);
        mainPanel.add(remoteFileViewer);
        mainPanel.add(taskViewer);
        mainPanel.add(stateBar);

    }
    
    private void initEventListener() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        menuConnect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    ftp.connect();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(mainPanel, "连接失败");
                }
                try {
                    ftp.login();
                    stateBar.setState(true, ftp.getHost());
                    JOptionPane.showMessageDialog(mainPanel, "登录成功");
                } catch (Exception ex){
                    JOptionPane.showMessageDialog(mainPanel, "登录失败");
                }
                
                
            }
        });
        
        menuSetting.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SettingDialog(ftp).setVisible(true);
            }
        });
        
        menuDisconnect.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e){
                ftp.disconnect();
                stateBar.setState(false, null);
                JOptionPane.showMessageDialog(mainPanel, "已断开连接");
            }
        });
        
        remoteFileViewer.setCallback(new MainCallback(){
            @Override
            public void onDownloadStart(FileRecord record, String localPath, String remotePath){
                TaskRecord task = new TaskRecord();
                task.name = record.name;
                task.total = record.size;
                task.localPath = localPath;
                task.remotePath = remotePath;
                task.state = TaskRecord.DOWNLOAD;
                taskViewer.addTask(task);
            }
            @Override
            public void onDownloadFailed(){
                taskViewer.currentTaskItem.setFailure();
                taskViewer.taskList.repaint();
            }
        });
        
        localFileViewer.setCallback(new MainCallback(){
            @Override
            public void onUploadStart(FileRecord record, String localPath, String remotePath){
                TaskRecord task = new TaskRecord();
                task.name = record.name;
                task.total = record.size;
                task.localPath = localPath;
                task.remotePath = remotePath;
                task.state = TaskRecord.UPLOAD;
                taskViewer.addTask(task);
            }
            @Override
            public void onUploadFailed(){
                taskViewer.currentTaskItem.setFailure();
                taskViewer.taskList.repaint();
            }
        });
    }
}

class StateBar extends JPanel{
    private FlowLayout layout;
    private JLabel state, des;

    public StateBar() {
        layout = new FlowLayout(FlowLayout.LEFT);
        setLayout(layout);
        state = new JLabel("未连接");
        des = new JLabel("127.0.0.1");
        des.setVisible(false);
        add(state);
        add(des);
    }
    
    public void setState(boolean connected, String host){
        if(connected){
            state.setText("连接至");
            des.setVisible(true);
            des.setText(host);
        }else{
            state.setText("未连接");
            des.setVisible(false);
        }
        
    }
    
    
}


