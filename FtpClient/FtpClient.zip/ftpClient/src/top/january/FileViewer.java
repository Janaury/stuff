/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package top.january;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;

/**
 *
 * @author janua
 */
public class FileViewer extends JPanel{
    BoxLayout layout;
    MainCallback callback;
    AddressBar addressBar;
    ComponentList fileViewer;
    Ftp ftp;
    
    
    public FileViewer(Ftp _ftp){
        ftp = _ftp;
        initComponent();
        initEventListener();

        callback = new MainCallback();
    }
    
    private void initComponent() {
        layout = new BoxLayout(this, BoxLayout.Y_AXIS);
        setLayout(layout);
        initAddressBar();
        initViewPanel();
        setPopoutMenu();
        setTitle();
    }
    private void initAddressBar(){
        addressBar = new AddressBar();
        addressBar.setMaximumSize(new Dimension(1920, 25));
        add(addressBar);
    }
    
    public void setTitle(){
        setBorder(BorderFactory.createTitledBorder("本地目录"));
    }
    
    public void setCallback(MainCallback cb){
        callback = cb;
    }
    
    private void initViewPanel(){
        fileViewer = new ComponentList();
        add(fileViewer);
    }
    
    public void showPath(){
        DefaultListModel a = new DefaultListModel();
        File dir = new File(addressBar.getAddress());
        if(!dir.isDirectory()){
            dir = new File("localFile/");
            addressBar.setAddress("localFile/");
        }
        File[] files = dir.listFiles();
        for(File file : files){
            FileRecord record = new FileRecord();
            record.parseLocal(file);
            a.addElement(new FileItem(record));
        }
        fileViewer.initData(a);
    }
    public void initEventListener() {
        addressBar.addActionListener((ActionEvent e) -> {
            showPath();
        });
    }
    
    public void setPopoutMenu(){
        JPopupMenu menu = new JPopupMenu();
        JMenuItem item1 = new JMenuItem("上传");
        menu.add(item1);
        item1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index = fileViewer.getSelectedIndex();
                FileItem fitem= (FileItem)fileViewer.getItem(index);
                String name = fitem.record.name;
                String localpath = addressBar.getAddress() + name;
                String remotePath = FtpUI.mainWindow.remoteFileViewer.addressBar.getAddress() + name;
                Thread upload = new Thread(()->{
                    try {
                        callback.onUploadStart(fitem.record, localpath, remotePath);
                        ftp.upload(localpath, remotePath);
                    } catch (Exception ex) {
                        callback.onUploadFailed();
                        JOptionPane.showMessageDialog(FtpUI.mainWindow, "上传失败");
                    }
                    FtpUI.mainWindow.remoteFileViewer.showPath();
                });
                upload.start();
                
            }
        });
        fileViewer.setPopMenu(menu);
    }

}

class AddressBar extends JPanel{
    
    private BoxLayout layout;
    private JLabel addressLabel;
    private JTextField addressField;
    private JButton goButton;
    
    public AddressBar(){
        layout = new BoxLayout(this, BoxLayout.X_AXIS);
        setLayout(layout);
        addressLabel = new JLabel("当前位置");
        addressField = new JTextField();
        goButton = new JButton("转到");
        add(addressLabel);
        add(Box.createHorizontalStrut(10));
        add(addressField);
        add(Box.createHorizontalStrut(10));
        add(goButton);
    }
    
    public void addActionListener(ActionListener l){
        goButton.addActionListener(l);
    }
    
    public String getAddress(){
        return addressField.getText();
    }
    public void setAddress(String path){
        addressField.setText(path);
    }
}

class FileItem extends IconLabel{
    final static AutoIcon DIR = new AutoIcon("icon/dir.png");
    final static AutoIcon FILE = new AutoIcon("icon/file.png");
    FileRecord record;
    
    public FileItem(FileRecord _record) {
        super(_record.name);
        AutoIcon icon = null;
        record = _record;
        if(record.type == FileRecord.DIR){
            icon = FileItem.DIR;
        }else{
            icon = FileItem.FILE;
        }
        setIcon(icon);
        setPreferredSize(new Dimension(70, 70));
    }
}
