/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package top.january;

import java.awt.GridBagConstraints;

/**
 *
 * @author janua
 */
public class GbcH extends GridBagConstraints{
    public GbcH() {
        weightx = 1;
        weighty = 1;
        gridx = 0;
        gridy = 0;
        gridwidth = 0;
        gridheight = 0;
        fill = GridBagConstraints.BOTH;
        nextLine();
    }
    
    public GridBagConstraints next(int width, double ratio){
        gridx += gridwidth;
        weightx = ratio;
        gridwidth = width;
        
        return this;
    }
    public GridBagConstraints next(int width){
       return next(width, 1);
    }
    public GridBagConstraints next(){
        return next(1,1);
    }
    
    public void nextLine(int height, double ratio){
        gridy += gridheight;
        gridx = 0;
        gridwidth = 0;
        gridheight = height;
        weighty = ratio;
        
        
    }
    public void nextLine(){
        nextLine(1, 1);
    }
}
