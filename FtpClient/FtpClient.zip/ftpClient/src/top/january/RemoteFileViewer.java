/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package top.january;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;

/**
 *
 * @author janua
 */
public class RemoteFileViewer extends FileViewer{
    boolean init;
    
    public RemoteFileViewer(Ftp _ftp) {
        super(_ftp);
    }
    
    @Override
    public void setTitle(){
        setBorder(BorderFactory.createTitledBorder("服务器目录"));
    }
    
    @Override
    public void showPath(){
        DefaultListModel a = new DefaultListModel();
        ArrayList<String> fileRecords = new ArrayList<String>();
        try{
            String path = addressBar.getAddress();
            if(path.equals("")){
                addressBar.setAddress("/");
                path = String.valueOf("/");
            }
            fileRecords = ftp.list(path);
            ftp.cwd(path);
        }catch(Exception e){
            try{
                fileRecords = ftp.list("/");
                ftp.cwd("/");
                addressBar.setAddress("/");
            }catch(Exception f){
                    JOptionPane.showMessageDialog(FtpUI.mainWindow, "无法读取远程目录");
            }
        }
        
        for(String fileRecord : fileRecords){
            FileRecord record = new FileRecord();
            record.parseRemote(fileRecord);
            a.addElement(new FileItem(record));
        }
        fileViewer.initData(a);
    }
    
    @Override
    public void setPopoutMenu(){
        JPopupMenu menu = new JPopupMenu();
        JMenuItem item1 = new JMenuItem("下载文件");
        JMenuItem item2 = new JMenuItem("创建文件夹");
        JMenuItem item3 = new JMenuItem("删除");
        menu.add(item1);
        menu.add(item2);
        menu.add(item3);
        
        item1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index = fileViewer.getSelectedIndex();
                FileItem fitem= (FileItem)fileViewer.getItem(index);
                String name = fitem.record.name;
                String path = addressBar.getAddress() + name;
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setSelectedFile(new File(name));
                fileChooser.showSaveDialog(null);
                String localpath = fileChooser.getSelectedFile().getPath();
                System.out.println(localpath);
                
                Thread download = new Thread(()->{
                    try {
                        callback.onDownloadStart(fitem.record, localpath, path);
                        ftp.download(path, localpath);
                    } catch (Exception ex) {
                        callback.onDownloadFailed();
                        JOptionPane.showMessageDialog(null, "下载失败");
                    }
                });
                download.start();
            }
        });
        item2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String dirName = JOptionPane.showInputDialog(FtpUI.mainWindow, "请输入新文件夹名");
                try {
                    ftp.mkdir(dirName);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(FtpUI.mainWindow, "文件夹创建失败");
                }
                showPath();
            }
        });
        
        item3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index = fileViewer.getSelectedIndex();
                FileItem fitem= (FileItem)fileViewer.getItem(index);
                String name = fitem.record.name;
                try{
                    if(fitem.record.type == FileRecord.DIR){
                        ftp.rmdir(name);
                    }else{
                        ftp.rmfile(name);
                    }
                }catch(Exception ex){
                    JOptionPane.showMessageDialog(FtpUI.mainWindow, "删除失败");
                }
                showPath();
                
            }
        });
        fileViewer.setPopMenu(menu);
    }
}
