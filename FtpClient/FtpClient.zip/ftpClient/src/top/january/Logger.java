
package top.january;

public class Logger {
    private boolean debug;
    
    public Logger(boolean _debug){
        debug = _debug;
    }
    public Logger(){
        debug = true;
    }
    
    public void logI(String info){
        String output = "Info: " + info;
        System.out.println(output);
    }
    public void logI(String info, Exception e){
        String output = "Info: " + info;
        System.out.println(output);
        System.err.println(e);
    }
    
    public void logD(String debug_info){
        if(debug){
            String output = "Debug: " + debug_info;
            System.out.println(output);
        }
    }
    
    public void logD(Exception e){
        if(debug){
            System.out.println(e);
        }
    }
    
    public void logE(String error_info){
        String output = "Error: " + error_info;
        System.err.println(output);
    }
    
    public void logE(String error_info, Exception e){
        String output = "Error: " + error_info;
        System.err.println(output);
        System.err.println(e);
    }
}
