/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package top.january;

import java.awt.Image;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import static javax.swing.SwingConstants.BOTTOM;
import static javax.swing.SwingConstants.CENTER;

/**
 *
 * @author janua
 */
//图标在上边，文字在下面的Label
class IconLabel extends JLabel{
    public IconLabel(String text, Icon icon){
        super(text);
        setIcon(icon);
    }
    public IconLabel(String text, String IconPath){
        super(text);
        AutoIcon icon = new AutoIcon(IconPath);
        setIcon(icon);
    }
    
    public IconLabel(String text){
        super(text);
    }
    
    @Override
    public void setIcon(Icon icon){
        super.setIcon(icon);
        setHorizontalTextPosition(CENTER);
        setVerticalTextPosition(BOTTOM);
    }
}

//可以设置尺寸的icon
class AutoIcon extends ImageIcon{
    private int width = 50;
    private int height = 50;
    public AutoIcon(String iconPath){
        super(iconPath);
        setImage(getImage().getScaledInstance(width, height, Image.SCALE_FAST));
    }
}
