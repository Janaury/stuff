/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package top.january;


import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;

/**
 *
 * @author janua
 */
public class TaskViewer extends JPanel{
    private Ftp ftp;
    private BoxLayout layout;
    private TaskTitle taskTitle;
    ComponentList taskList;
    private DefaultListModel taskModel;
    TaskItem currentTaskItem;
    
    public TaskViewer(Ftp _ftp){
        ftp = _ftp;
        initComponent();
        initEventListener();
    }

    private void initEventListener() {
        
    }

    private void initComponent() {
        layout = new BoxLayout(this, BoxLayout.Y_AXIS);
        setLayout(layout);
        taskTitle = new TaskTitle();
        initTaskList();
        taskTitle.setMaximumSize(new Dimension(Short.MAX_VALUE, 25));
        add(taskTitle);
        add(taskList);
        setBorder(BorderFactory.createTitledBorder("传输历史"));
        
    }
    
    private void initTaskList(){
        taskModel = new DefaultListModel();
        taskList = new ComponentList();
        taskList.setVertical();
        setPopoutMenu();
    }
    
    public void setPopoutMenu(){
        JPopupMenu menu = new JPopupMenu();
        JMenuItem item1, item2, item3;
        item1 = new JMenuItem("暂停");
        item2 = new JMenuItem("继续");
        item3 = new JMenuItem("删除");
        menu.add(item1);
        menu.add(item2);
        menu.add(item3);
        item1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index = taskList.getSelectedIndex();
                TaskItem item = (TaskItem)taskList.getItem(index);
                ftp.pause();
                item.setPause();
                taskList.repaint();
            }
        });
        item2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index = taskList.getSelectedIndex();
                TaskItem item = (TaskItem)taskList.getItem(index);
                TaskRecord record  = item.record;
                currentTaskItem = item;
                if(!record.activated){
                    item.setResume();
                    if(record.state == TaskRecord.DOWNLOAD){
                        ftp.setCallback(new MainCallback(){
                             @Override
                             public void onDownload(int size){
                                 SwingUtilities.invokeLater(()->{
                                     currentTaskItem.setProcess(size);
                                     taskList.repaint();
                                 });
                             }
                          });
                        Thread download = new Thread(()->{
                            try {
                                 ftp.resumeDownload(record.remotePath, record.localPath);
                             } catch (Exception ex) {
                                 item.setFailure();
                                 taskList.repaint();
                                 JOptionPane.showMessageDialog(FtpUI.mainWindow, "下载失败");
                             }
                        });
                        download.start();
                     
                     }else{
                         ftp.setCallback(new MainCallback(){
                             @Override
                             public void onUpload(int size){

                                 SwingUtilities.invokeLater(()->{
                                     currentTaskItem.setProcess(size);
                                     taskList.repaint();
                                 });
                             }
                          });
                         Thread upload = new Thread(()->{
                            try {
                                 ftp.resumeUpload(record.localPath, record.remotePath);
                             } catch (Exception ex) {
                                 item.setFailure();
                                 taskList.repaint();
                                 JOptionPane.showMessageDialog(FtpUI.mainWindow, "上传失败");
                             }
                        });
                        upload.start();
                     }
                }
                
            }
        });
        
        item3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int index = taskList.getSelectedIndex();
                TaskItem item = (TaskItem)taskList.getItem(index);
                if(item.record.activated){
                    ftp.pause();
                    item.setPause();
                }
                taskList.removeItem(index);
            }
        });
        taskList.setPopMenu(menu);
    }
    
    public void addTask(TaskRecord task){
        currentTaskItem = new TaskItem(task);
        taskList.addItem(currentTaskItem);
        if(task.state == TaskRecord.DOWNLOAD){
           ftp.setCallback(new MainCallback(){
                @Override
                public void onDownload(int size){

                    SwingUtilities.invokeLater(()->{
                        currentTaskItem.setProcess(size);
                        taskList.repaint();
                    });
                }
             });
        }else{
            ftp.setCallback(new MainCallback(){
                @Override
                public void onUpload(int size){

                    SwingUtilities.invokeLater(()->{
                        currentTaskItem.setProcess(size);
                        taskList.repaint();
                    });
                }
             });
        }
        
    }
    
}

class TaskTitle extends JPanel{
    private BoxLayout layout;
    private JLabel name, process, state;

    public TaskTitle() {
        layout = new BoxLayout(this, BoxLayout.X_AXIS);
        setLayout(layout);
        name = new JLabel("文件名");
        name.setMaximumSize(new Dimension(150, 25));
        process = new JLabel("传输进度");
        process.setMaximumSize(new Dimension(300, 25));
        state = new JLabel("状态");
        state.setMaximumSize(new Dimension(100, 25));
        
        add(name);
        add(Box.createHorizontalStrut(10));
        add(process);
        add(Box.createHorizontalStrut(10));
        add(state);

    }
}

class TaskItem extends JPanel{
    private BoxLayout layout;
    private JLabel namelLabel, stateLabel;
    private JProgressBar processBar;
    TaskRecord record;
    
    public TaskItem(TaskRecord _record){
        layout = new BoxLayout(this, BoxLayout.X_AXIS);
        setLayout(layout);
        record = _record;
        namelLabel = new JLabel(record.name);
        namelLabel.setMaximumSize(new Dimension(150, 25));
        processBar = new JProgressBar();
        processBar.setMaximumSize(new Dimension(300, 25));
        processBar.setValue((int) (record.now * 100 / record.total));
        if(record.state == TaskRecord.DOWNLOAD){
            stateLabel = new JLabel("下载中");
        }else{
            stateLabel = new JLabel("上传中");
        }
        stateLabel.setMaximumSize(new Dimension(100, 25));
       
        setPreferredSize(new Dimension(0, 25));
        add(namelLabel);
        add(Box.createHorizontalStrut(10));
        add(processBar);
        add(Box.createHorizontalStrut(10));
        add(stateLabel);        
    }
    
    public void setPause(){
        record.activated = false;
        if(record.state == TaskRecord.DOWNLOAD){
            stateLabel.setText("下载暂停");
        }else{
            stateLabel.setText("上传暂停");
        }
    }
    
    public void setFailure(){
        record.activated = false;
        if(record.state == TaskRecord.DOWNLOAD){
            stateLabel.setText("下载失败");
        }else{
            stateLabel.setText("上传失败");
        }
    }
    
    public void setResume(){
        record.activated = true;
        if(record.state == TaskRecord.DOWNLOAD){
            stateLabel.setText("下载中");
        }else{
            stateLabel.setText("上传中");
        }
    }
    
    public void setProcess(int num){
        record.now += num;
        processBar.setValue((int) (record.now * 100 / record.total));
        System.out.println(processBar.getValue());
        if(record.now >= record.total){
            record.activated = false;
            if(record.state == TaskRecord.DOWNLOAD){
                stateLabel.setText("下载完成");
            }else{
                stateLabel.setText("上传完成");
            }
        }
    }
}

class PopMenu extends JPopupMenu{
    public JMenuItem item1,item2,item3;

    public PopMenu() {
       
    }
}

class TaskRecord{
    final static int UPLOAD = 0;
    final static int DOWNLOAD = 1;
    String name = "default task";
    String localPath = "test.txt";
    String remotePath = "test.txt";
    long now = 0;
    long total = 1;
    int state = TaskRecord.DOWNLOAD;
    boolean activated = true;
    
    
}
    