/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package top.january;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.DefaultListModel;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;


/**
 *
 * @author janua
 */
public class ComponentList extends JScrollPane{
    private JList list;
    private DefaultListModel listModel;
    
    public ComponentList(){
       listModel = new DefaultListModel();
       initComponent();
    }
    public void setVertical(){
        list.setLayoutOrientation(JList.VERTICAL);
    }
    public void setHorizontal(){
        list.setLayoutOrientation(JList.HORIZONTAL_WRAP);
        list.setVisibleRowCount(0);
    }
   
    public void initData(DefaultListModel _ListModel){
        listModel = _ListModel;
        list.setModel(listModel);
    }
    
    public void addItem(Object object){
        listModel.addElement(object);
        list.setModel(listModel);
    }
    
    public void removeItem(int index){
        listModel.remove(index);
        list.setModel(listModel);
    }
    
    private void initComponent(){
        list = new JList();
        setHorizontal();
        //fileList.setOpaque(false);
        list.setCellRenderer(new ComponentRender());
        setViewportView(list);
    }
    
    public void setPopMenu(JPopupMenu popMenu){
        list.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e){
                if(e.getButton() == e.BUTTON3){
                    int index = list.locationToIndex(e.getPoint());  
                    list.setSelectedIndex(index);
                    popMenu.show(list, e.getX(), e.getY());
                }else{
                    popMenu.setVisible(false);
                }
                
            }
});
    }
    
    public void fresh(){
        list.setModel(listModel);
    }
    
    public int getSelectedIndex(){
        return list.getSelectedIndex();
    }
    public Object getLastItem(){
        return listModel.get(listModel.getSize() - 1);
        
    }
    public Object getItem(int index){
        return listModel.get(index);
    }
    
}
