/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package top.january;

import java.util.*;
import java.net.Socket;
import java.io.*;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketAddress;
import java.util.logging.Level;
/**
 *
 * @author janua
 */
public class Ftp {
    //log信息
    Logger log;
    //缓冲区
    char[] cbuf = new char[1024];
    private String reply;
    //配置信息
    private int timeout;
    private String remoteHost;
    private int remotePort;
    private String username;
    private String password;
    //传输通道资源
    private Socket ctrlSocket;
    private BufferedReader ctrlReplyStream;
    private BufferedWriter ctrlCommandStream;
    //状态
    private boolean enrolled = false;
    
    //回调函数接口
    private MainCallback callback;
    
    //用于暂停
    private boolean pause = false;
    
    
    public Ftp(){
        log = new Logger();
        remotePort = 21;
        remoteHost = "localhost";
        timeout = 4000;
        callback = new MainCallback();
        username = "january";
        password = "120120";
    }
    
////    //测试运行的主函数
////    public static void main(String[] args) {
////        // TODO code application logic here
////        Ftp ftp = new Ftp();
////        ftp.test();
////    }
////    
////    //测试使用方法
////    public void test(){
////        try {
////            connect();
////            login("january", "4545");
////            upload("G:\\workplace\\ftpClient\\ftpTest\\t.pdf", "t.pdf");
////            resumeUpload("G:\\workplace\\ftpClient\\ftpTest\\t.pdf", "t.pdf");
//////            try {
//////                download("test.png", ".\\ftpTest\\hello.png");
//////            } catch (Exception ex) {
//////                java.util.logging.Logger.getLogger(Ftp.class.getName()).log(Level.SEVERE, null, ex);
//////            }
//////            cwd("hello");
////           list("");
//////            download("rfc959.pdf", "./ftpTest/t.pdf");
//////            resumeDownload("rfc959.pdf", "./ftpTest/t.pdf");
////            disconnect();
////        } catch (Exception ex) {
////            java.util.logging.Logger.getLogger(Ftp.class.getName()).log(Level.SEVERE, null, ex);
////        }
//       
//
//        
//    }
    
    public String getUser(){
        return username;
    }
    public void setUser(String _username){
        username = _username;
    }
    public String getPass(){
        return password;
    }
    public void setPass(String _password){
        password = _password;
    }
    public String getHost(){
        return remoteHost;
    }
    public void SetHost(String host){
        remoteHost = host;
    }
    
    
    public void setCallback(MainCallback _callback){
        callback = _callback;
    }
    public void pause(){
        pause = true;
    }
    
    private void resetConnection(){
        try {
            ctrlCommandStream.close();
            ctrlReplyStream.close();
            ctrlSocket.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        ctrlSocket = null;
        enrolled = false; 
    }
    
    private boolean checkCtrlConnection(){
        boolean result = (ctrlSocket == null)? false : true;
        return result;
    }
    
    private void sendCommand(String command) throws Exception{
        if(!checkCtrlConnection()){
            throw new RuntimeException("no connection");
        }
        try{
            ctrlCommandStream.write(command + "\r\n");
            ctrlCommandStream.flush();
        }catch(Exception e){
            resetConnection();
            log.logD(e);
            throw new RuntimeException("bad connection");
        }
    }
    
    private void getReply() throws IOException{
        int bytesRead = ctrlReplyStream.read(cbuf);
        reply = new String(cbuf, 0, bytesRead);
        log.logD(reply);
    }
    
    private Socket createDataConnection() throws Exception{
        sendCommand(FtpCommand.PASV);
        getReply();
        if(!reply.startsWith("227")){
            log.logD(reply);
            throw new RuntimeException("ftp error");
        }
       
        int addressStartIndex = reply.indexOf('(');
        int addressEndIndex = reply.indexOf(')');
        
        if(addressEndIndex <= 0){
            throw new RuntimeException("ftp server error, no address in reply");
        }
        String reply_address = reply.substring(addressStartIndex + 1, addressEndIndex);
        StringTokenizer arg = new StringTokenizer(reply_address, ",", false);
        String remoteIp = String.format(Const.IPV4FORMAT, arg.nextToken(),arg.nextToken(),arg.nextToken(),arg.nextToken());
        int remoteDataPort = (Integer.parseInt(arg.nextToken()) << 8) + Integer.parseInt(arg.nextToken());
        log.logD(reply_address);
        Socket dataSocket = new Socket(remoteIp, remoteDataPort);
        dataSocket.setSoTimeout(5000);
        return dataSocket;
    }
    
    private void doDownload(File localFile, Socket dataSocket, boolean append) throws Exception{
        FileOutputStream fileOutputStream = new FileOutputStream(localFile, append);
        BufferedInputStream dataDownloadStream = new BufferedInputStream(dataSocket.getInputStream());
        int bytesRead = 0;
        byte[] buffer = new byte[4096];
        for(;;){
            bytesRead = dataDownloadStream.read(buffer);
            if(bytesRead == -1){
                break;
            }
            fileOutputStream.write(buffer, 0, bytesRead);
            Thread.sleep(1000);
            callback.onDownload(bytesRead);
            if(pause){
                abort();
                pause = false;
                break;
            }
        }
        fileOutputStream.flush();
        fileOutputStream.close();
        dataSocket.close();
    }
    
    private void doUpload(File localFile, Socket dataSocket, long offset) throws Exception{
        RandomAccessFile fileInputStream = new RandomAccessFile(localFile, "r");
        BufferedOutputStream dataUploadStream = new BufferedOutputStream(dataSocket.getOutputStream());
        int bytesRead = 0;
        byte[] buffer = new byte[4096];
        if(offset != 0){
            fileInputStream.seek(offset);
        }
        int total = 0;
        for(;;){
            bytesRead = fileInputStream.read(buffer);
            if(bytesRead == -1){
                break;
            }
            dataUploadStream.write(buffer, 0, bytesRead);
            callback.onUpload(bytesRead);
            Thread.sleep(1000);
            if(pause){
                abort();
                pause = false;
                break;
            }
        }
        try{
            dataUploadStream.flush();
        }finally{
            fileInputStream.close();
            dataUploadStream.close();
            dataSocket.close();
        }
    }
    
    public void abort() throws Exception{
        sendCommand(FtpCommand.ABORT);
        getReply();
    }
    
    public void connect()throws Exception{
        InetSocketAddress remoteAddress = new InetSocketAddress(remoteHost, remotePort);
        if(ctrlSocket == null){
            ctrlSocket = new Socket();
            ctrlSocket.connect(remoteAddress, timeout);
            ctrlSocket.setSoTimeout(timeout);
            ctrlReplyStream = new BufferedReader(new InputStreamReader(ctrlSocket.getInputStream()));
            ctrlCommandStream = new BufferedWriter(new OutputStreamWriter(ctrlSocket.getOutputStream()));
            log.logI("connection success");
            try{
                //尝试读取欢迎消息
                getReply();
            }catch(Exception e){
                log.logI("no welcome message");
            }
        }else{
            log.logI("already connected");
        } 
    }
    
    public void login() throws Exception{
        login(username, password);
    }
    
    public void login(String username, String password)throws Exception{
        sendCommand(FtpCommand.USER + username);
        getReply();
        if(!reply.startsWith("331")){
            throw new RuntimeException("username is not correct");
        }
        sendCommand(FtpCommand.PASS + password);
        getReply();
        if(!reply.startsWith("230")){
            throw new RuntimeException("username doesn't match password"); 
        }
        log.logI("login success");  
    }
    
    public void resumeUpload(String localFilePath, String remoteFilePath) throws Exception{
        ServerFileRecord thisFile = new ServerFileRecord(list(remoteFilePath).get(0));
        int offset = thisFile.getSize();
        Socket dataSocket = createDataConnection();
        File file = new File(localFilePath);
        sendCommand(FtpCommand.APPEND + remoteFilePath);
        getReply();
        if(!reply.startsWith("1")){
            throw new RuntimeException("ftp error");
        }
        doUpload(file, dataSocket, offset);
        getReply();
        if(!reply.startsWith("226")){
            throw new RuntimeException("ftp error");
        }
        log.logI("upload success");
    }

    public void upload(String localFilePath, String remoteFilePath) throws Exception{
        Socket dataSocket = createDataConnection();
        File file = new File(localFilePath);
        sendCommand(FtpCommand.STOR + remoteFilePath);
        getReply();
        if(!reply.startsWith("1")){
            throw new RuntimeException("ftp error");
        }
        doUpload(file, dataSocket, 0);
        getReply();
        if(!reply.startsWith("226")){
            throw new RuntimeException("ftp error");
        }
        log.logI("upload success");
    }
   
    public void resumeDownload(String remotePath, String localPath) throws Exception{
        Socket dataSocket = createDataConnection();
        File localFile = new File(localPath);
        long currentFileLen = localFile.length();
        sendCommand(FtpCommand.RESET + String.valueOf(currentFileLen));
        getReply();
        if(!reply.startsWith("350")){
            throw new RuntimeException("ftp error");
        }
        sendCommand(FtpCommand.RETR + remotePath);
        getReply();
        if(!reply.startsWith("1")){
            throw new RuntimeException("ftp error");
        }
        doDownload(localFile, dataSocket, true);
        getReply();
        if(!reply.startsWith("226")){
            throw new RuntimeException("ftp error");
        }
        log.logI("download success");
    }
    
    public void download(String remotePath, String localPath) throws Exception{
        Socket dataSocket = createDataConnection();
        File newLocalFile = new File(localPath);
        sendCommand(FtpCommand.RETR + remotePath);
        getReply();
        if(!reply.startsWith("1")){
            throw new RuntimeException("ftp error");
        }
        boolean ok = newLocalFile.createNewFile();
        if(!ok){
            //throw new RuntimeException("file already exists");
            log.logI("file already exists");
        }
        
        doDownload(newLocalFile, dataSocket, false);
        getReply();
        if(!reply.startsWith("226")){
            //throw new RuntimeException("ftp error");
        }
        log.logI("download success");
    }
    
    public ArrayList<String> list(String remoteDirPath) throws Exception{
        Socket dataSocket = createDataConnection();
        ArrayList<String> fileRecordList = new ArrayList<String>();
        sendCommand(FtpCommand.LIST + remoteDirPath);
        getReply();
        if(!reply.startsWith("1")){
            throw new RuntimeException("ftp error");
        }
        BufferedReader readStream = new BufferedReader(new InputStreamReader(dataSocket.getInputStream()));
        String fileRecord = null;
        while((fileRecord = readStream.readLine()) != null){
            fileRecordList.add(fileRecord);
        }
        readStream.close();
        dataSocket.close();
        getReply();
        if(!reply.startsWith("226")){
            throw new RuntimeException("ftp error");
        }
        log.logI("get directory content sucessfully");
        for(String fr : fileRecordList){
            System.out.println(fr);
        }
    
        return fileRecordList;
    }
    
    public String pwd() throws Exception{
        sendCommand(FtpCommand.PWD);
        getReply();
        if(!reply.startsWith("257")){
            throw new RuntimeException("ftp error");
        }
        int currentDirStartIndex = reply.indexOf("\"");
        int currentDirEndIndex = reply.indexOf("\"", currentDirStartIndex + 1);
        if(currentDirEndIndex <= 0){
            throw new RuntimeException("ftp server error");
        }
        String currentDir = reply.substring(currentDirStartIndex + 1, currentDirEndIndex);
        log.logD(currentDir);
        return currentDir;
    }
    
    public void cwd(String remoteDirPath) throws Exception{
        if(remoteDirPath.equals("/")){
            return;
        }
        sendCommand(FtpCommand.CWD + remoteDirPath);
        getReply();
        if(!reply.startsWith("250")){
            throw new RuntimeException("ftp error");
        }
        log.logI("change directory to " + remoteDirPath);
    }
    
    public void mkdir(String remoteDirPath) throws Exception{
        if(remoteDirPath.equals("/")){
            log.logI("don't need to create root directory");
            return;
        }
        sendCommand(FtpCommand.MKDIR + remoteDirPath);
        getReply();
        if(!reply.startsWith("257")){
            throw new RuntimeException("ftp error");
        }
        log.logI("create directory" + remoteDirPath);
    }
    
    public void rmdir(String remoteDirPath) throws Exception{
        if(remoteDirPath.equals("/")){
            log.logI("can't delete root directory");
            return;
        }
        sendCommand(FtpCommand.RMDIR + remoteDirPath);
        getReply();
        if(!reply.startsWith("250")){
            throw new RuntimeException("ftp error");
        }
        log.logI("delete directory" + remoteDirPath);
    }
    
    public void rmfile(String remoteFilePath) throws Exception{
        sendCommand(FtpCommand.RM + remoteFilePath);
        getReply();
        if(!reply.startsWith("250")){
            throw new RuntimeException("ftp error");
        }
        log.logI("delete directory" + remoteFilePath);
    }
    
    public void disconnect(){
        try{
            sendCommand(FtpCommand.QUIT);
            
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            resetConnection();
        }
    }
}

class ServerFileRecord{
    final static int FILE = 0;
    final static int DIR = 1;
    private String name;
    private int type;
    private int size;

    public ServerFileRecord(String fileRecord) {
        String[] fileInfo = fileRecord.split(" +");
        name = fileInfo[8];
        type = (fileInfo[0].startsWith("d"))? ServerFileRecord.DIR : ServerFileRecord.FILE;
        size = Integer.parseInt(fileInfo[4]);
    }
    
    public int getSize(){
        return size;
    }
    public int getType(){
        return type;
    }
    public String getName(){
        return name;
    }
}
        
class FtpCommand{
    final static String USER = "USER ";
    final static String PASS = "PASS ";
    final static String PASV = "PASV ";
    final static String STOR = "STOR ";
    final static String RETR = "RETR ";
    final static String LIST = "LIST ";
    final static String QUIT = "QUIT ";
    final static String PWD = "PWD";
    final static String CWD = "CWD ";
    final static String MKDIR = "MKD ";
    final static String RMDIR = "RMD ";
    final static String RM = "DELE ";
    final static String RESET = "REST ";
    final static String APPEND = "APPE ";
    final static String ABORT = "ABOR";
}

class Const{
    final static String IPV4FORMAT = "%s.%s.%s.%s";
}